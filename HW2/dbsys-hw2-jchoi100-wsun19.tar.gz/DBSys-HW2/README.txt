dbsys-hw2

Name: Joon Hyuck Choi, William Sun
JHED: jchoi100, wsun19

We implemented exercises 1, 2, 3, 4, 6 fully and 5 partially.
Please refer to dbsys_hw2_jchoi100_wsun19_experiments.pdf for
the experiment results and discussions.

Before running any tests, please remember to rm -rf data.
(It has already been removed in our submission.)
